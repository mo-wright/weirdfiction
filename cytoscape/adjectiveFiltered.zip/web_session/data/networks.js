var networks = {"adjFILTERED.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "adjFILTERED.tsv",
    "name" : "adjFILTERED.tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "1260",
        "synset" : 36,
        "ClosenessCentrality" : 0.4347826086956522,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9235294117647058,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "fallen",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "fallen",
        "SelfLoops" : 0,
        "SUID" : 1260,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.3,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -1071.81760519721,
        "y" : -156.2245508784492
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "synset" : 31,
        "ClosenessCentrality" : 0.4347826086956522,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9235294117647058,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "clean",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "clean",
        "SelfLoops" : 0,
        "SUID" : 1153,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.3,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : -1257.5781718448552,
        "y" : -123.01831041992159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "ClosenessCentrality" : 0.7407407407407407,
        "Eccentricity" : 3,
        "Degree" : 247,
        "PartnerOfMultiEdgedNodePairs" : 15,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9794117647058823,
        "Stress" : 464,
        "TopologicalCoefficient" : 0.875,
        "shared_name" : "poeSentences",
        "BetweennessCentrality" : 0.4342105263157895,
        "NumberOfUndirectedEdges" : 247,
        "name" : "poeSentences",
        "SelfLoops" : 0,
        "SUID" : 783,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.35,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.875
      },
      "position" : {
        "x" : -207.5781718448552,
        "y" : -198.0183104199216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "synset" : 25,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "round",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 7,
        "name" : "round",
        "SelfLoops" : 0,
        "SUID" : 602,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -1332.5781718448552,
        "y" : -198.0183104199216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "synset" : 25,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "striking",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 4,
        "name" : "striking",
        "SelfLoops" : 0,
        "SUID" : 575,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -357.5781718448552,
        "y" : -348.0183104199216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "synset" : 25,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "square",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 10,
        "name" : "square",
        "SelfLoops" : 0,
        "SUID" : 524,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -207.5781718448552,
        "y" : -398.0183104199216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "synset" : 30,
        "ClosenessCentrality" : 0.45454545454545453,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9294117647058824,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "following",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "following",
        "SelfLoops" : 0,
        "SUID" : 511,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 692.4218281551448,
        "y" : 51.98168958007841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "synset" : 27,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "covered",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 3,
        "name" : "covered",
        "SelfLoops" : 0,
        "SUID" : 502,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -1032.5781718448552,
        "y" : 326.9816895800784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "synset" : 72,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "broken",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 9,
        "name" : "broken",
        "SelfLoops" : 0,
        "SUID" : 487,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 315.3441467788604,
        "y" : -118.86294766735287
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "synset" : 26,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "closed",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 5,
        "name" : "closed",
        "SelfLoops" : 0,
        "SUID" : 342,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 642.4218281551448,
        "y" : -73.01831041992159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "synset" : 47,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 27,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "light",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 27,
        "name" : "light",
        "SelfLoops" : 0,
        "SUID" : 285,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 197.0886702140608,
        "y" : -84.68541556721163
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "synset" : 35,
        "ClosenessCentrality" : 0.45454545454545453,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9294117647058824,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "go",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "go",
        "SelfLoops" : 0,
        "SUID" : 270,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 617.4218281551448,
        "y" : 226.9816895800784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "synset" : 28,
        "ClosenessCentrality" : 0.45454545454545453,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9294117647058824,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "back",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "name" : "back",
        "SelfLoops" : 0,
        "SUID" : 259,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 692.4218281551448,
        "y" : 151.9816895800784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "synset" : 37,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 46,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "close",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 46,
        "name" : "close",
        "SelfLoops" : 0,
        "SUID" : 244,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 67.4218281551448,
        "y" : -23.01831041992159
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "synset" : 45,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 45,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "clear",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 45,
        "name" : "clear",
        "SelfLoops" : 0,
        "SUID" : 239,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 442.4218281551448,
        "y" : 276.9816895800784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "synset" : 30,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 50,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "heavy",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 50,
        "name" : "heavy",
        "SelfLoops" : 0,
        "SUID" : 230,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -57.578171844855206,
        "y" : 26.98168958007841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "synset" : 36,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 52,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "right",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 52,
        "name" : "right",
        "SelfLoops" : 0,
        "SUID" : 213,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 442.4218281551448,
        "y" : -198.0183104199216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "synset" : 25,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 59,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "white",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 59,
        "name" : "white",
        "SelfLoops" : 0,
        "SUID" : 208,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -432.5781718448552,
        "y" : 226.9816895800784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "synset" : 36,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 86,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "open",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 86,
        "name" : "open",
        "SelfLoops" : 0,
        "SUID" : 199,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -332.5781718448552,
        "y" : 151.9816895800784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "ClosenessCentrality" : 0.8,
        "Eccentricity" : 3,
        "Degree" : 269,
        "PartnerOfMultiEdgedNodePairs" : 12,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9852941176470589,
        "Stress" : 524,
        "TopologicalCoefficient" : 0.8235294117647058,
        "shared_name" : "lovecraftSentences",
        "BetweennessCentrality" : 0.5236842105263158,
        "NumberOfUndirectedEdges" : 269,
        "name" : "lovecraftSentences",
        "SelfLoops" : 0,
        "SUID" : 185,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.25,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.8235294117647058
      },
      "position" : {
        "x" : 453.31678650416524,
        "y" : 73.16843366010319
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "synset" : 27,
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Degree" : 103,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9470588235294118,
        "Stress" : 24,
        "TopologicalCoefficient" : 0.8611111111111112,
        "shared_name" : "good",
        "BetweennessCentrality" : 0.004511278195488721,
        "NumberOfUndirectedEdges" : 103,
        "name" : "good",
        "SelfLoops" : 0,
        "SUID" : 183,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -207.5781718448552,
        "y" : 76.98168958007841
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1263",
        "source" : "1260",
        "target" : "783",
        "EdgeBetweenness" : 39.99999999999999,
        "shared_name" : "fallen (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "fallen (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1263,
        "BEND_MAP_ID" : 1263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1180",
        "source" : "1153",
        "target" : "783",
        "EdgeBetweenness" : 39.99999999999999,
        "shared_name" : "clean (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clean (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1180,
        "BEND_MAP_ID" : 1180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1156",
        "source" : "1153",
        "target" : "783",
        "EdgeBetweenness" : 39.99999999999999,
        "shared_name" : "clean (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clean (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1156,
        "BEND_MAP_ID" : 1156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1218",
        "source" : "602",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "round (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1218,
        "BEND_MAP_ID" : 1218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "602",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "round (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1158,
        "BEND_MAP_ID" : 1158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "source" : "602",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "round (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1133,
        "BEND_MAP_ID" : 1133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "602",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "round (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1071,
        "BEND_MAP_ID" : 1071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "602",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "round (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1049,
        "BEND_MAP_ID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "source" : "602",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "round (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 897,
        "BEND_MAP_ID" : 897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "602",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "round (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "round (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 605,
        "BEND_MAP_ID" : 605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1256",
        "source" : "575",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "striking (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "striking (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1256,
        "BEND_MAP_ID" : 1256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "source" : "575",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "striking (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "striking (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1149,
        "BEND_MAP_ID" : 1149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "source" : "575",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "striking (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "striking (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 977,
        "BEND_MAP_ID" : 977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "575",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "striking (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "striking (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 578,
        "BEND_MAP_ID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1226",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1226,
        "BEND_MAP_ID" : 1226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1220",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1220,
        "BEND_MAP_ID" : 1220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1200,
        "BEND_MAP_ID" : 1200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1107,
        "BEND_MAP_ID" : 1107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1099,
        "BEND_MAP_ID" : 1099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 853,
        "BEND_MAP_ID" : 853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 817,
        "BEND_MAP_ID" : 817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "524",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "square (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 797,
        "BEND_MAP_ID" : 797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "524",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "square (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 565,
        "BEND_MAP_ID" : 565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "source" : "524",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "square (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "square (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 527,
        "BEND_MAP_ID" : 527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "source" : "511",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "following (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "following (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 514,
        "BEND_MAP_ID" : 514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "502",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "covered (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "covered (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1069,
        "BEND_MAP_ID" : 1069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "502",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "covered (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "covered (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1047,
        "BEND_MAP_ID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "source" : "502",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "covered (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "covered (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 505,
        "BEND_MAP_ID" : 505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1224",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1224,
        "BEND_MAP_ID" : 1224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1117,
        "BEND_MAP_ID" : 1117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1113,
        "BEND_MAP_ID" : 1113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 965,
        "BEND_MAP_ID" : 965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 943,
        "BEND_MAP_ID" : 943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 899,
        "BEND_MAP_ID" : 899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "source" : "487",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "broken (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 827,
        "BEND_MAP_ID" : 827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "source" : "487",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "broken (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 600,
        "BEND_MAP_ID" : 600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "source" : "487",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "broken (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 490,
        "BEND_MAP_ID" : 490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1244",
        "source" : "342",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "closed (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "closed (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1244,
        "BEND_MAP_ID" : 1244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "342",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "closed (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "closed (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 809,
        "BEND_MAP_ID" : 809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "342",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "closed (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "closed (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 707,
        "BEND_MAP_ID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "source" : "342",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "closed (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "closed (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 459,
        "BEND_MAP_ID" : 459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "source" : "342",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "closed (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "closed (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 345,
        "BEND_MAP_ID" : 345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1279,
        "BEND_MAP_ID" : 1279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1271",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1271,
        "BEND_MAP_ID" : 1271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1258",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1258,
        "BEND_MAP_ID" : 1258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1242",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1242,
        "BEND_MAP_ID" : 1242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1210",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1210,
        "BEND_MAP_ID" : 1210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1202",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1202,
        "BEND_MAP_ID" : 1202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1194",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1194,
        "BEND_MAP_ID" : 1194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1192",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1192,
        "BEND_MAP_ID" : 1192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1174,
        "BEND_MAP_ID" : 1174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1170",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1170,
        "BEND_MAP_ID" : 1170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1160",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1160,
        "BEND_MAP_ID" : 1160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1081,
        "BEND_MAP_ID" : 1081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1059,
        "BEND_MAP_ID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1003,
        "BEND_MAP_ID" : 1003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1001,
        "BEND_MAP_ID" : 1001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 989,
        "BEND_MAP_ID" : 989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 979,
        "BEND_MAP_ID" : 979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "source" : "285",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "light (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 885,
        "BEND_MAP_ID" : 885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 651,
        "BEND_MAP_ID" : 651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 551,
        "BEND_MAP_ID" : 551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 543,
        "BEND_MAP_ID" : 543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 473,
        "BEND_MAP_ID" : 473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 467,
        "BEND_MAP_ID" : 467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 465,
        "BEND_MAP_ID" : 465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 463,
        "BEND_MAP_ID" : 463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 421,
        "BEND_MAP_ID" : 421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "285",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "light (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 288,
        "BEND_MAP_ID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "source" : "270",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "go (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "go (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 273,
        "BEND_MAP_ID" : 273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "259",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "back (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "back (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 669,
        "BEND_MAP_ID" : 669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "source" : "259",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "back (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "back (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 655,
        "BEND_MAP_ID" : 655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "259",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "back (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "back (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 304,
        "BEND_MAP_ID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "source" : "259",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "back (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "back (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 277,
        "BEND_MAP_ID" : 277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "259",
        "target" : "185",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "back (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "back (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 262,
        "BEND_MAP_ID" : 262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1232",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1232,
        "BEND_MAP_ID" : 1232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1164,
        "BEND_MAP_ID" : 1164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1121,
        "BEND_MAP_ID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1095,
        "BEND_MAP_ID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1077,
        "BEND_MAP_ID" : 1077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1055,
        "BEND_MAP_ID" : 1055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1007,
        "BEND_MAP_ID" : 1007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1005,
        "BEND_MAP_ID" : 1005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 969,
        "BEND_MAP_ID" : 969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 967,
        "BEND_MAP_ID" : 967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 913,
        "BEND_MAP_ID" : 913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 873,
        "BEND_MAP_ID" : 873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 863,
        "BEND_MAP_ID" : 863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "source" : "244",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "close (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 793,
        "BEND_MAP_ID" : 793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 773,
        "BEND_MAP_ID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 771,
        "BEND_MAP_ID" : 771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 751,
        "BEND_MAP_ID" : 751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 745,
        "BEND_MAP_ID" : 745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 721,
        "BEND_MAP_ID" : 721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 705,
        "BEND_MAP_ID" : 705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 699,
        "BEND_MAP_ID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 667,
        "BEND_MAP_ID" : 667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 663,
        "BEND_MAP_ID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 659,
        "BEND_MAP_ID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 639,
        "BEND_MAP_ID" : 639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 633,
        "BEND_MAP_ID" : 633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 598,
        "BEND_MAP_ID" : 598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 592,
        "BEND_MAP_ID" : 592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 580,
        "BEND_MAP_ID" : 580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 561,
        "BEND_MAP_ID" : 561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 555,
        "BEND_MAP_ID" : 555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 549,
        "BEND_MAP_ID" : 549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 533,
        "BEND_MAP_ID" : 533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 522,
        "BEND_MAP_ID" : 522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 494,
        "BEND_MAP_ID" : 494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 461,
        "BEND_MAP_ID" : 461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 411,
        "BEND_MAP_ID" : 411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 409,
        "BEND_MAP_ID" : 409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 389,
        "BEND_MAP_ID" : 389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 383,
        "BEND_MAP_ID" : 383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 359,
        "BEND_MAP_ID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 340,
        "BEND_MAP_ID" : 340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 334,
        "BEND_MAP_ID" : 334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 302,
        "BEND_MAP_ID" : 302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 298,
        "BEND_MAP_ID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "244",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "close (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "close (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 247,
        "BEND_MAP_ID" : 247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1236",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1236,
        "BEND_MAP_ID" : 1236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1204",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1204,
        "BEND_MAP_ID" : 1204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1190",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1190,
        "BEND_MAP_ID" : 1190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1188",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1188,
        "BEND_MAP_ID" : 1188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1184",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1184,
        "BEND_MAP_ID" : 1184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1151,
        "BEND_MAP_ID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1119,
        "BEND_MAP_ID" : 1119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1035,
        "BEND_MAP_ID" : 1035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1023,
        "BEND_MAP_ID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 999,
        "BEND_MAP_ID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 947,
        "BEND_MAP_ID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 921,
        "BEND_MAP_ID" : 921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 911,
        "BEND_MAP_ID" : 911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 905,
        "BEND_MAP_ID" : 905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 901,
        "BEND_MAP_ID" : 901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 893,
        "BEND_MAP_ID" : 893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 891,
        "BEND_MAP_ID" : 891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 889,
        "BEND_MAP_ID" : 889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 829,
        "BEND_MAP_ID" : 829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "239",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "clear (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 795,
        "BEND_MAP_ID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 779,
        "BEND_MAP_ID" : 779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 689,
        "BEND_MAP_ID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 677,
        "BEND_MAP_ID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 661,
        "BEND_MAP_ID" : 661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 653,
        "BEND_MAP_ID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 645,
        "BEND_MAP_ID" : 645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 627,
        "BEND_MAP_ID" : 627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 623,
        "BEND_MAP_ID" : 623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 621,
        "BEND_MAP_ID" : 621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 573,
        "BEND_MAP_ID" : 573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 557,
        "BEND_MAP_ID" : 557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 545,
        "BEND_MAP_ID" : 545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 531,
        "BEND_MAP_ID" : 531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 529,
        "BEND_MAP_ID" : 529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 509,
        "BEND_MAP_ID" : 509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 500,
        "BEND_MAP_ID" : 500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 498,
        "BEND_MAP_ID" : 498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 485,
        "BEND_MAP_ID" : 485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 451,
        "BEND_MAP_ID" : 451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 417,
        "BEND_MAP_ID" : 417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 324,
        "BEND_MAP_ID" : 324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 312,
        "BEND_MAP_ID" : 312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 296,
        "BEND_MAP_ID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 275,
        "BEND_MAP_ID" : 275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "239",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "clear (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 242,
        "BEND_MAP_ID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1254",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1254,
        "BEND_MAP_ID" : 1254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1252",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1252,
        "BEND_MAP_ID" : 1252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1238",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1238,
        "BEND_MAP_ID" : 1238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1127,
        "BEND_MAP_ID" : 1127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1105,
        "BEND_MAP_ID" : 1105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1101,
        "BEND_MAP_ID" : 1101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1089,
        "BEND_MAP_ID" : 1089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1079,
        "BEND_MAP_ID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1075,
        "BEND_MAP_ID" : 1075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1067,
        "BEND_MAP_ID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1057,
        "BEND_MAP_ID" : 1057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1053,
        "BEND_MAP_ID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 997,
        "BEND_MAP_ID" : 997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 995,
        "BEND_MAP_ID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 993,
        "BEND_MAP_ID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 985,
        "BEND_MAP_ID" : 985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 895,
        "BEND_MAP_ID" : 895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 865,
        "BEND_MAP_ID" : 865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "230",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "heavy (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 855,
        "BEND_MAP_ID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 781,
        "BEND_MAP_ID" : 781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 743,
        "BEND_MAP_ID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 741,
        "BEND_MAP_ID" : 741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 729,
        "BEND_MAP_ID" : 729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 723,
        "BEND_MAP_ID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 693,
        "BEND_MAP_ID" : 693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 691,
        "BEND_MAP_ID" : 691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 657,
        "BEND_MAP_ID" : 657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 629,
        "BEND_MAP_ID" : 629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 596,
        "BEND_MAP_ID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 569,
        "BEND_MAP_ID" : 569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 541,
        "BEND_MAP_ID" : 541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 520,
        "BEND_MAP_ID" : 520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 516,
        "BEND_MAP_ID" : 516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 483,
        "BEND_MAP_ID" : 483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 477,
        "BEND_MAP_ID" : 477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 475,
        "BEND_MAP_ID" : 475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 453,
        "BEND_MAP_ID" : 453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 437,
        "BEND_MAP_ID" : 437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 419,
        "BEND_MAP_ID" : 419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 381,
        "BEND_MAP_ID" : 381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 379,
        "BEND_MAP_ID" : 379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 367,
        "BEND_MAP_ID" : 367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 361,
        "BEND_MAP_ID" : 361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 328,
        "BEND_MAP_ID" : 328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 326,
        "BEND_MAP_ID" : 326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 290,
        "BEND_MAP_ID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 268,
        "BEND_MAP_ID" : 268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 257,
        "BEND_MAP_ID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 253,
        "BEND_MAP_ID" : 253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "source" : "230",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "heavy (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 233,
        "BEND_MAP_ID" : 233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1198",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1198,
        "BEND_MAP_ID" : 1198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1182,
        "BEND_MAP_ID" : 1182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1176,
        "BEND_MAP_ID" : 1176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1166,
        "BEND_MAP_ID" : 1166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1143,
        "BEND_MAP_ID" : 1143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1103,
        "BEND_MAP_ID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1097,
        "BEND_MAP_ID" : 1097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1087,
        "BEND_MAP_ID" : 1087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1085,
        "BEND_MAP_ID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1065,
        "BEND_MAP_ID" : 1065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1063,
        "BEND_MAP_ID" : 1063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1031,
        "BEND_MAP_ID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1019,
        "BEND_MAP_ID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 959,
        "BEND_MAP_ID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 937,
        "BEND_MAP_ID" : 937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 935,
        "BEND_MAP_ID" : 935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 933,
        "BEND_MAP_ID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 931,
        "BEND_MAP_ID" : 931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 923,
        "BEND_MAP_ID" : 923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 907,
        "BEND_MAP_ID" : 907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 837,
        "BEND_MAP_ID" : 837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 813,
        "BEND_MAP_ID" : 813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "213",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "right (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 807,
        "BEND_MAP_ID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 759,
        "BEND_MAP_ID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 733,
        "BEND_MAP_ID" : 733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 717,
        "BEND_MAP_ID" : 717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 713,
        "BEND_MAP_ID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 703,
        "BEND_MAP_ID" : 703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 701,
        "BEND_MAP_ID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 687,
        "BEND_MAP_ID" : 687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 683,
        "BEND_MAP_ID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 681,
        "BEND_MAP_ID" : 681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 649,
        "BEND_MAP_ID" : 649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 647,
        "BEND_MAP_ID" : 647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 631,
        "BEND_MAP_ID" : 631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 479,
        "BEND_MAP_ID" : 479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 397,
        "BEND_MAP_ID" : 397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 371,
        "BEND_MAP_ID" : 371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 355,
        "BEND_MAP_ID" : 355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 351,
        "BEND_MAP_ID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 338,
        "BEND_MAP_ID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 336,
        "BEND_MAP_ID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 322,
        "BEND_MAP_ID" : 322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 318,
        "BEND_MAP_ID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 316,
        "BEND_MAP_ID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 283,
        "BEND_MAP_ID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 281,
        "BEND_MAP_ID" : 281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 266,
        "BEND_MAP_ID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 249,
        "BEND_MAP_ID" : 249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 228,
        "BEND_MAP_ID" : 228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 226,
        "BEND_MAP_ID" : 226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "source" : "213",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "right (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 216,
        "BEND_MAP_ID" : 216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1283,
        "BEND_MAP_ID" : 1283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1281,
        "BEND_MAP_ID" : 1281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1275",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1275,
        "BEND_MAP_ID" : 1275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1267,
        "BEND_MAP_ID" : 1267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1265,
        "BEND_MAP_ID" : 1265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1234",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1234,
        "BEND_MAP_ID" : 1234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1216",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1216,
        "BEND_MAP_ID" : 1216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1214",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1214,
        "BEND_MAP_ID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1186",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1186,
        "BEND_MAP_ID" : 1186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1178",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1178,
        "BEND_MAP_ID" : 1178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1147,
        "BEND_MAP_ID" : 1147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1093,
        "BEND_MAP_ID" : 1093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1091,
        "BEND_MAP_ID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1073,
        "BEND_MAP_ID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1051,
        "BEND_MAP_ID" : 1051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1045,
        "BEND_MAP_ID" : 1045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1009,
        "BEND_MAP_ID" : 1009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 991,
        "BEND_MAP_ID" : 991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 987,
        "BEND_MAP_ID" : 987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 971,
        "BEND_MAP_ID" : 971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 961,
        "BEND_MAP_ID" : 961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 957,
        "BEND_MAP_ID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 955,
        "BEND_MAP_ID" : 955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 941,
        "BEND_MAP_ID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 903,
        "BEND_MAP_ID" : 903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 875,
        "BEND_MAP_ID" : 875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 869,
        "BEND_MAP_ID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 861,
        "BEND_MAP_ID" : 861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "source" : "208",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "white (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 849,
        "BEND_MAP_ID" : 849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 775,
        "BEND_MAP_ID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 695,
        "BEND_MAP_ID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 679,
        "BEND_MAP_ID" : 679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 675,
        "BEND_MAP_ID" : 675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 673,
        "BEND_MAP_ID" : 673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 665,
        "BEND_MAP_ID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 635,
        "BEND_MAP_ID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 619,
        "BEND_MAP_ID" : 619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 617,
        "BEND_MAP_ID" : 617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 615,
        "BEND_MAP_ID" : 615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 613,
        "BEND_MAP_ID" : 613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 559,
        "BEND_MAP_ID" : 559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 471,
        "BEND_MAP_ID" : 471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 445,
        "BEND_MAP_ID" : 445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 435,
        "BEND_MAP_ID" : 435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 433,
        "BEND_MAP_ID" : 433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 429,
        "BEND_MAP_ID" : 429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 427,
        "BEND_MAP_ID" : 427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 425,
        "BEND_MAP_ID" : 425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 413,
        "BEND_MAP_ID" : 413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 330,
        "BEND_MAP_ID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 314,
        "BEND_MAP_ID" : 314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 310,
        "BEND_MAP_ID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 308,
        "BEND_MAP_ID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 300,
        "BEND_MAP_ID" : 300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 251,
        "BEND_MAP_ID" : 251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 224,
        "BEND_MAP_ID" : 224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 220,
        "BEND_MAP_ID" : 220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 218,
        "BEND_MAP_ID" : 218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "208",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "white (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 211,
        "BEND_MAP_ID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1273",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1273,
        "BEND_MAP_ID" : 1273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1269",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1269,
        "BEND_MAP_ID" : 1269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1250",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1250,
        "BEND_MAP_ID" : 1250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1248",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1248,
        "BEND_MAP_ID" : 1248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1246",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1246,
        "BEND_MAP_ID" : 1246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1240",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1240,
        "BEND_MAP_ID" : 1240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1230",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1230,
        "BEND_MAP_ID" : 1230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1228",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1228,
        "BEND_MAP_ID" : 1228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1222",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1222,
        "BEND_MAP_ID" : 1222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1212",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1212,
        "BEND_MAP_ID" : 1212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1208",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1208,
        "BEND_MAP_ID" : 1208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1172,
        "BEND_MAP_ID" : 1172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1168",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1168,
        "BEND_MAP_ID" : 1168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1145,
        "BEND_MAP_ID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1141,
        "BEND_MAP_ID" : 1141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1135,
        "BEND_MAP_ID" : 1135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1131,
        "BEND_MAP_ID" : 1131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1125,
        "BEND_MAP_ID" : 1125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1115,
        "BEND_MAP_ID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1111,
        "BEND_MAP_ID" : 1111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1041,
        "BEND_MAP_ID" : 1041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1029,
        "BEND_MAP_ID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 981,
        "BEND_MAP_ID" : 981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 953,
        "BEND_MAP_ID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 939,
        "BEND_MAP_ID" : 939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 841,
        "BEND_MAP_ID" : 841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 833,
        "BEND_MAP_ID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 821,
        "BEND_MAP_ID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 801,
        "BEND_MAP_ID" : 801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 791,
        "BEND_MAP_ID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "199",
        "target" : "783",
        "EdgeBetweenness" : 20.714285714285715,
        "shared_name" : "open (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 785,
        "BEND_MAP_ID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 769,
        "BEND_MAP_ID" : 769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 765,
        "BEND_MAP_ID" : 765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 763,
        "BEND_MAP_ID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 761,
        "BEND_MAP_ID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 757,
        "BEND_MAP_ID" : 757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 755,
        "BEND_MAP_ID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 753,
        "BEND_MAP_ID" : 753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 749,
        "BEND_MAP_ID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 747,
        "BEND_MAP_ID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 737,
        "BEND_MAP_ID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 735,
        "BEND_MAP_ID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 731,
        "BEND_MAP_ID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 727,
        "BEND_MAP_ID" : 727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 719,
        "BEND_MAP_ID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 715,
        "BEND_MAP_ID" : 715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 711,
        "BEND_MAP_ID" : 711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 709,
        "BEND_MAP_ID" : 709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 643,
        "BEND_MAP_ID" : 643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 641,
        "BEND_MAP_ID" : 641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 637,
        "BEND_MAP_ID" : 637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 625,
        "BEND_MAP_ID" : 625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 611,
        "BEND_MAP_ID" : 611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 609,
        "BEND_MAP_ID" : 609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 590,
        "BEND_MAP_ID" : 590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 553,
        "BEND_MAP_ID" : 553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 547,
        "BEND_MAP_ID" : 547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 539,
        "BEND_MAP_ID" : 539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 535,
        "BEND_MAP_ID" : 535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 518,
        "BEND_MAP_ID" : 518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 507,
        "BEND_MAP_ID" : 507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 492,
        "BEND_MAP_ID" : 492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 469,
        "BEND_MAP_ID" : 469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 457,
        "BEND_MAP_ID" : 457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 423,
        "BEND_MAP_ID" : 423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 407,
        "BEND_MAP_ID" : 407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 403,
        "BEND_MAP_ID" : 403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 401,
        "BEND_MAP_ID" : 401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 399,
        "BEND_MAP_ID" : 399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 395,
        "BEND_MAP_ID" : 395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 393,
        "BEND_MAP_ID" : 393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 391,
        "BEND_MAP_ID" : 391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 387,
        "BEND_MAP_ID" : 387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 385,
        "BEND_MAP_ID" : 385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 375,
        "BEND_MAP_ID" : 375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 373,
        "BEND_MAP_ID" : 373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 369,
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 365,
        "BEND_MAP_ID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 357,
        "BEND_MAP_ID" : 357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 353,
        "BEND_MAP_ID" : 353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 349,
        "BEND_MAP_ID" : 349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 347,
        "BEND_MAP_ID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 292,
        "BEND_MAP_ID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 279,
        "BEND_MAP_ID" : 279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 204,
        "BEND_MAP_ID" : 204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "source" : "199",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "open (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "open (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 202,
        "BEND_MAP_ID" : 202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1277,
        "BEND_MAP_ID" : 1277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1206",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1206,
        "BEND_MAP_ID" : 1206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1196",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1196,
        "BEND_MAP_ID" : 1196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1162",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1162,
        "BEND_MAP_ID" : 1162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1139,
        "BEND_MAP_ID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1137,
        "BEND_MAP_ID" : 1137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1129,
        "BEND_MAP_ID" : 1129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1123,
        "BEND_MAP_ID" : 1123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1109,
        "BEND_MAP_ID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1083,
        "BEND_MAP_ID" : 1083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1061,
        "BEND_MAP_ID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1043,
        "BEND_MAP_ID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1039,
        "BEND_MAP_ID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1037,
        "BEND_MAP_ID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1033,
        "BEND_MAP_ID" : 1033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1027,
        "BEND_MAP_ID" : 1027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1025,
        "BEND_MAP_ID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1021,
        "BEND_MAP_ID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1017,
        "BEND_MAP_ID" : 1017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1015,
        "BEND_MAP_ID" : 1015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1013,
        "BEND_MAP_ID" : 1013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 1011,
        "BEND_MAP_ID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 983,
        "BEND_MAP_ID" : 983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 975,
        "BEND_MAP_ID" : 975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 973,
        "BEND_MAP_ID" : 973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 963,
        "BEND_MAP_ID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 951,
        "BEND_MAP_ID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 949,
        "BEND_MAP_ID" : 949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 945,
        "BEND_MAP_ID" : 945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 929,
        "BEND_MAP_ID" : 929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 927,
        "BEND_MAP_ID" : 927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 925,
        "BEND_MAP_ID" : 925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 919,
        "BEND_MAP_ID" : 919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 917,
        "BEND_MAP_ID" : 917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 915,
        "BEND_MAP_ID" : 915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 909,
        "BEND_MAP_ID" : 909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 887,
        "BEND_MAP_ID" : 887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 883,
        "BEND_MAP_ID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 881,
        "BEND_MAP_ID" : 881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 879,
        "BEND_MAP_ID" : 879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 877,
        "BEND_MAP_ID" : 877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 871,
        "BEND_MAP_ID" : 871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 867,
        "BEND_MAP_ID" : 867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 859,
        "BEND_MAP_ID" : 859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 857,
        "BEND_MAP_ID" : 857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 851,
        "BEND_MAP_ID" : 851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 847,
        "BEND_MAP_ID" : 847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 845,
        "BEND_MAP_ID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 843,
        "BEND_MAP_ID" : 843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 839,
        "BEND_MAP_ID" : 839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 835,
        "BEND_MAP_ID" : 835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 831,
        "BEND_MAP_ID" : 831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 825,
        "BEND_MAP_ID" : 825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 823,
        "BEND_MAP_ID" : 823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 819,
        "BEND_MAP_ID" : 819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 815,
        "BEND_MAP_ID" : 815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 811,
        "BEND_MAP_ID" : 811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 805,
        "BEND_MAP_ID" : 805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 803,
        "BEND_MAP_ID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 799,
        "BEND_MAP_ID" : 799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 789,
        "BEND_MAP_ID" : 789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "source" : "183",
        "target" : "783",
        "EdgeBetweenness" : 20.71428571428571,
        "shared_name" : "good (interacts with) poeSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) poeSentences",
        "interaction" : "interacts with",
        "SUID" : 787,
        "BEND_MAP_ID" : 787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 777,
        "BEND_MAP_ID" : 777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 767,
        "BEND_MAP_ID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 739,
        "BEND_MAP_ID" : 739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 725,
        "BEND_MAP_ID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 697,
        "BEND_MAP_ID" : 697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 685,
        "BEND_MAP_ID" : 685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 671,
        "BEND_MAP_ID" : 671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 607,
        "BEND_MAP_ID" : 607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 594,
        "BEND_MAP_ID" : 594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 588,
        "BEND_MAP_ID" : 588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 586,
        "BEND_MAP_ID" : 586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 584,
        "BEND_MAP_ID" : 584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 582,
        "BEND_MAP_ID" : 582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 571,
        "BEND_MAP_ID" : 571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 567,
        "BEND_MAP_ID" : 567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 563,
        "BEND_MAP_ID" : 563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 537,
        "BEND_MAP_ID" : 537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 496,
        "BEND_MAP_ID" : 496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 481,
        "BEND_MAP_ID" : 481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 455,
        "BEND_MAP_ID" : 455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 449,
        "BEND_MAP_ID" : 449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 447,
        "BEND_MAP_ID" : 447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 443,
        "BEND_MAP_ID" : 443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 441,
        "BEND_MAP_ID" : 441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 439,
        "BEND_MAP_ID" : 439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 431,
        "BEND_MAP_ID" : 431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 415,
        "BEND_MAP_ID" : 415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 405,
        "BEND_MAP_ID" : 405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 377,
        "BEND_MAP_ID" : 377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 363,
        "BEND_MAP_ID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 332,
        "BEND_MAP_ID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 320,
        "BEND_MAP_ID" : 320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 306,
        "BEND_MAP_ID" : 306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 294,
        "BEND_MAP_ID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 264,
        "BEND_MAP_ID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 255,
        "BEND_MAP_ID" : 255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 237,
        "BEND_MAP_ID" : 237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 235,
        "BEND_MAP_ID" : 235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 222,
        "BEND_MAP_ID" : 222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 206,
        "BEND_MAP_ID" : 206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "source" : "183",
        "target" : "185",
        "EdgeBetweenness" : 22.714285714285715,
        "shared_name" : "good (interacts with) lovecraftSentences",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) lovecraftSentences",
        "interaction" : "interacts with",
        "SUID" : 197,
        "BEND_MAP_ID" : 197,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}